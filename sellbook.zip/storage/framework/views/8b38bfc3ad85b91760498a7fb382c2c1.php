<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\xampp\htdocs\sellbook\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>