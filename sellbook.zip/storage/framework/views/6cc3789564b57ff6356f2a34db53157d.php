<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\sellbook\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>